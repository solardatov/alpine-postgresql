/* src/include/port/dgux.h */

/* nothing needed */
