/* $PostgreSQL: pgsql/src/interfaces/ecpg/include/decimal.h,v 1.19 2009/06/11 14:49:13 momjian Exp $ */

#ifndef _ECPG_DECIMAL_H
#define _ECPG_DECIMAL_H

#include <ecpg_informix.h>

#ifndef _ECPGLIB_H				/* source created by ecpg which defines this
								 * symbol */
typedef decimal dec_t;
#endif   /* ndef _ECPGLIB_H */

#endif   /* ndef _ECPG_DECIMAL_H */
