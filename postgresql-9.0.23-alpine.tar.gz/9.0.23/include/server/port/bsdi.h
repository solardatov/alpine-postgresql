/*
 * $PostgreSQL: pgsql/src/include/port/bsdi.h,v 1.15 2009/06/11 14:49:11 momjian Exp $
 */
