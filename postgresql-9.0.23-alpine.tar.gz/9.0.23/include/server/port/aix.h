/*
 * $PostgreSQL: pgsql/src/include/port/aix.h,v 1.13 2009/06/11 14:49:11 momjian Exp $
 */
#define CLASS_CONFLICT
#define DISABLE_XOPEN_NLS
