/*
 * $PostgreSQL: pgsql/src/include/port/unixware.h,v 1.19 2009/06/11 14:49:12 momjian Exp $
 *
 * see src/backend/libpq/pqcomm.c */
#define SCO_ACCEPT_BUG

/***************************************
 * Define this if you are compiling with
 * the native UNIXWARE C compiler.
 ***************************************/
#define USE_UNIVEL_CC
