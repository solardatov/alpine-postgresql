/* $PostgreSQL: pgsql/src/include/port/hpux.h,v 1.24 2007/04/06 05:36:51 tgl Exp $ */

/* nothing needed */
