/*
 * $PostgreSQL: pgsql/src/include/port/sco.h,v 1.19 2009/06/11 14:49:11 momjian Exp $
 *
 * see src/backend/libpq/pqcomm.c */
#define SCO_ACCEPT_BUG

#define USE_UNIVEL_CC
