#ifndef _ECPG_DECIMAL_H
#define _ECPG_DECIMAL_H

#include <ecpg_informix.h>

typedef decimal dec_t;

#endif /* ndef _ECPG_DECIMAL_H */
