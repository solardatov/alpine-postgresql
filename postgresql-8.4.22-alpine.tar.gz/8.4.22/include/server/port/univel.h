/*
 * $PostgreSQL: pgsql/src/include/port/univel.h,v 1.25 2009/06/11 14:49:12 momjian Exp $
 *
 ***************************************
 * Define this if you are compiling with
 * the native UNIXWARE C compiler.
 ***************************************/
#define USE_UNIVEL_CC
