/*
 * $PostgreSQL: pgsql/src/include/port/win32/sys/wait.h,v 1.4 2009/06/11 14:49:12 momjian Exp $
 */
