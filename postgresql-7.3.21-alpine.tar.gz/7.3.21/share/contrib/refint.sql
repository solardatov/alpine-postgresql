-- Adjust this setting to control where the objects get created.
SET search_path = public;

SET autocommit TO 'on';

CREATE OR REPLACE FUNCTION check_primary_key()
RETURNS trigger
AS '$libdir/refint'
LANGUAGE 'C';

CREATE OR REPLACE FUNCTION check_foreign_key()
RETURNS trigger
AS '$libdir/refint'
LANGUAGE 'C';
