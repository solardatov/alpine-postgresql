-- Adjust this setting to control where the objects get created.
SET search_path = public;

SET autocommit TO 'on';

CREATE OR REPLACE FUNCTION noup ()
RETURNS trigger
AS '$libdir/noup'
LANGUAGE 'C';
