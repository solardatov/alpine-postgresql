DROP FUNCTION pgstattuple(NAME);
CREATE FUNCTION pgstattuple(NAME) RETURNS FLOAT8
AS '$libdir/pgstattuple', 'pgstattuple'
LANGUAGE 'c' WITH (isstrict);
