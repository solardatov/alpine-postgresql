DROP FUNCTION autoinc();

CREATE FUNCTION autoinc() 
	RETURNS opaque 
	AS '$libdir/autoinc'
	LANGUAGE 'C';
