DROP FUNCTION noup ();

CREATE FUNCTION noup ()
	RETURNS opaque
	AS '$libdir/noup'
	LANGUAGE 'C';
