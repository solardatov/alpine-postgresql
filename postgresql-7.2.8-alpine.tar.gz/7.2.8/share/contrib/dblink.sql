CREATE FUNCTION dblink (text,text) RETURNS setof int
  AS '$libdir/dblink','dblink' LANGUAGE 'c';

CREATE FUNCTION dblink_tok (int,int) RETURNS text
  AS '$libdir/dblink','dblink_tok' LANGUAGE 'c';
