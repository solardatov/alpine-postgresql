CREATE FUNCTION levenshtein (text,text) RETURNS int
  AS '$libdir/fuzzystrmatch','levenshtein' LANGUAGE 'c' with (iscachable, isstrict);

CREATE FUNCTION metaphone (text,int) RETURNS text
  AS '$libdir/fuzzystrmatch','metaphone' LANGUAGE 'c' with (iscachable, isstrict);

CREATE FUNCTION soundex(text) RETURNS text
  AS '$libdir/fuzzystrmatch', 'soundex' LANGUAGE 'c' with (iscachable, isstrict);

CREATE FUNCTION text_soundex(text) RETURNS text
  AS '$libdir/fuzzystrmatch', 'soundex' LANGUAGE 'c' with (iscachable, isstrict);
