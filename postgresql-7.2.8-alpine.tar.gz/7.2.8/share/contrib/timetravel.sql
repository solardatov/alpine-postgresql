DROP FUNCTION timetravel();
DROP FUNCTION set_timetravel(name, int4);

CREATE FUNCTION timetravel() 
	RETURNS opaque 
	AS '$libdir/timetravel'
	LANGUAGE 'C';

CREATE FUNCTION set_timetravel(name, int4) 
	RETURNS int4 
	AS '$libdir/timetravel'
	LANGUAGE 'C' WITH (isStrict);
