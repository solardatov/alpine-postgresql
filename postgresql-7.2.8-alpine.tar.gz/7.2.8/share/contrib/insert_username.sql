DROP FUNCTION insert_username();

CREATE FUNCTION insert_username() 
	RETURNS opaque 
	AS '$libdir/insert_username'
	LANGUAGE 'C';
