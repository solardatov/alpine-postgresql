--
--	PostgreSQL code for CHKPASS.
--  Written by D'Arcy J.M. Cain
--  darcy@druid.net
--  http://www.druid.net/darcy/
-- 
--  $Header: /cvsroot/pgsql/contrib/chkpass/chkpass.sql.in,v 1.1.2.1 2005/01/29 22:36:03 tgl Exp $
--
--  best viewed with tabs set to 4
--

--
--	Input and output functions and the type itself:
--

create function chkpass_in(opaque)
	returns opaque
	as '$libdir/chkpass'
	language 'c' with (isStrict);

create function chkpass_out(opaque)
	returns opaque
	as '$libdir/chkpass'
	language 'c' with (isStrict);

create type chkpass (
	internallength = 16,
	externallength = 13,
	input = chkpass_in,
	output = chkpass_out
);

create function raw(chkpass)
	returns text
	as '$libdir/chkpass', 'chkpass_rout'
	language 'c' with (isStrict);

--
--	The various boolean tests:
--

create function eq(chkpass, text)
	returns bool
	as '$libdir/chkpass', 'chkpass_eq'
	language 'c' with (isStrict);

create function ne(chkpass, text)
	returns bool
	as '$libdir/chkpass', 'chkpass_ne'
	language 'c' with (isStrict);

--
--	Now the operators.  Note how some of the parameters to some
--	of the 'create operator' commands are commented out.  This
--	is because they reference as yet undefined operators, and
--	will be implicitly defined when those are, further down.
--

create operator = (
	leftarg = chkpass,
	rightarg = text,
	commutator = =,
--	negator = <>,
	procedure = eq
);

create operator <> (
	leftarg = chkpass,
	rightarg = text,
	negator = =,
	procedure = ne
);

COMMENT ON TYPE chkpass IS 'password type with checks';

--
--	eof
--
