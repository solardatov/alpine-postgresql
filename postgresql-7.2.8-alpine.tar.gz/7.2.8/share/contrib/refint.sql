DROP FUNCTION check_primary_key ();
DROP FUNCTION check_foreign_key ();

CREATE FUNCTION check_primary_key ()
	RETURNS opaque
	AS '$libdir/refint'
	LANGUAGE 'C';

CREATE FUNCTION check_foreign_key ()
	RETURNS opaque
	AS '$libdir/refint'
	LANGUAGE 'C';
