create function fti() returns opaque as
	'$libdir/fti'
	language 'C';