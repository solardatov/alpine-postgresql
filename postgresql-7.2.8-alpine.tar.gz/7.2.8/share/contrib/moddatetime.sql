DROP FUNCTION moddatetime();

CREATE FUNCTION moddatetime() 
	RETURNS opaque 
	AS '$libdir/moddatetime'
	LANGUAGE 'C';
